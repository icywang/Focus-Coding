package model;

/**
 * @author ximengw
 *
 * Class Account: manages account information and 
 * interacts with db
 */
public class Account {

	private String username;
	private String passwd;
	
	private String leetAccount;
	
	
	
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the leetAccount
	 */
	public String getLeetAccount() {
		return leetAccount;
	}
	/**
	 * @param leetAccount the leetAccount to set
	 */
	public void setLeetAccount(String leetAccount) {
		this.leetAccount = leetAccount;
	}
	/**
	 * @return the passwd
	 */
	public String getPasswd() {
		return passwd;
	}
	/**
	 * @param passwd the passwd to set
	 */
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	} 
	
	
	
}
