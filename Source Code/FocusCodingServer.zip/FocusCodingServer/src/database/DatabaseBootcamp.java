package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseBootcamp {
	// JDBC driver and url
	private static final String JDBC_Driver = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/";

	// Database credential
	private static final String UserName = "root";
	private static final String PassWord = "tartans@1";
	private static final String DB_NAME = "FocusCodeDB";

	// Create table query
	private static final String TB_FC_Account = "CREATE TABLE TB_FC_ACCOUNT("
			+ "_ID INT AUTO_INCREMENT," 
			+ "USERNAME VARCHAR(20),"
			+ "PASSWORD VARCHAR(20)," 
			+ "LEETUSER VARCHAR(20),"
			+ "LEETPASS VARCHAR(20)," 
			+ "EMAIL VARCHAR(20),"
			+ "REGISTER_TIME VARCHAR(20),"
			+ "PRIMARY KEY(_ID) );";
	private static final String INCREMENT2 = "SET @@auto_increment_increment=2;";
	private static final String INCREMENT1 = "SET @@auto_increment_increment=1;";
	private static final String OFFSET1 = "SET @@auto_increment_offset=1;";
	private static final String OFFSET2 = "SET @@auto_increment_offset=2;";
	private static final String TB_LC_Account = "CREATE TABLE TB_LC_ACCOUNT("
			+ "_ID INT AUTO_INCREMENT," 
			+ "LEETUSER VARCHAR(20),"
			+ "LEETPASS VARCHAR(20)," 
			+ "REGISTER_TIME VARCHAR(20),"
			+ "PRIMARY KEY(_ID) );";
	private static final String TB_RECORD_DETAIL = "CREATE TABLE TB_RECORD_DETAIL("
			+ "_ID INT AUTO_INCREMENT,"
			+ "USER_ID INT,"
			+ "GOAL INT,"
			+ "ACTUAL INT,"
			+ "DATE VARCHAR(20),"
			+ "START_TIME VARCHAR(20),"
			+ "END_TIME VARCHAR(20),"
			+ "PRIMARY KEY(_ID) );";
	private static final String TB_RECORD_STAT = "CREATE TABLE TB_RECORD_STAT("
			+ "_ID INT AUTO_INCREMENT,"
			+ "USER_ID INT,"
			+ "SOLVED_PROB INT,"
			+ "LOCATION VARCHAR(20),"
			+ "PRIMARY KEY(_ID));";

	
	public static void main(String[] args){
		
		CreateDB();
		CreateTable();
		
	}
	

	// Create Database
	private static void CreateDB() {
		Connection conn = null;
		Statement stat = null;
		String createDB = null;
		try {
			// step1: Register jdbc driver
			Class.forName(JDBC_Driver);
			System.out.println("Success loading Mysql Driver!");
		} catch (Exception e) {
			System.out.println("Fail in loading Mysql Driver!");
			e.printStackTrace();
		}

		try {
			// step2: Open a connection
			conn = DriverManager.getConnection(DB_URL, UserName, PassWord);
			System.out.println("Success connecting to database.");
		} catch (Exception e) {
			System.out.println("Fail in connecting to database.");
			e.printStackTrace();
		}

		try {
			// step3: Execute a query
			stat = conn.createStatement();
			createDB = "CREATE DATABASE " + DB_NAME;
			stat.executeUpdate(createDB);
			System.out.println("Success creating databse " + DB_NAME);
		} catch (Exception e) {
			System.out.println("Fail in creating database.");
			e.printStackTrace();
		}
	}

	private static void CreateTable() {
		Connection conn = null;
		Statement stat = null;
		String createSTAT = null;
		try {
			// step1: Register jdbc driver
			Class.forName(JDBC_Driver);
			System.out.println("Success loading Mysql Driver!");
		} catch (Exception e) {
			System.out.println("Fail in loading Mysql Driver!");
			e.printStackTrace();
		}

		try {
			// step2: Open a connection
			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName,
					PassWord);
			System.out.println("Success connecting to database.");
		} catch (Exception e) {
			System.out.println("Fail in connecting to database.");
			e.printStackTrace();
		}

		try {
			// step3: Set the increment = 2 and offset = 1
			stat = conn.createStatement();
			String set = INCREMENT2;
			stat.execute(set);
			set = OFFSET1;
			stat.execute(set);
			//step4: Create TB_FC_Account
			createSTAT = TB_FC_Account;
			stat.execute(createSTAT);
			System.out.println("Success creating table TB_FC_Account.");
			//step5: Set the increment = 2 and offset = 2
			set = OFFSET2;
			stat.execute(set);
			//step6: Create TB_LC_Account
			createSTAT = TB_LC_Account;
			stat.execute(createSTAT);
			System.out.println("Success creating table TB_LC_Account.");
			//step7:Set the increment = 1 and offset = 2
			set = INCREMENT1;
			stat.execute(set);
			set = OFFSET1;
			stat.execute(set);
			//step8: create TB_RECORD_DETAIL
			createSTAT = TB_RECORD_DETAIL;
			stat.execute(createSTAT);
			//step9: create TB_RECORD_STAT
			createSTAT = TB_RECORD_STAT;
			stat.execute(createSTAT);
			
		} catch (Exception e) {
			System.out.println("Fail in creating TABLE.");
			e.printStackTrace();
		}
	}

}
