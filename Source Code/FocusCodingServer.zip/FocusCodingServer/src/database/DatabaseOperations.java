/**
 * 
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import util.ConnLeetCode;

/**
 * @author icywang
 *
 */
public class DatabaseOperations {
	// JDBC driver and url
	private static final String JDBC_Driver = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/";
	// Database credential
	private static final String UserName = "root";
	private static final String PassWord = "tartans@1";
	private static final String DB_NAME = "FocusCodeDB";

	private static final String insertFCA = "INSERT INTO TB_FC_Account "
			+ "(USERNAME, PASSWORD, LEETUSER, LEETPASS, EMAIL, REGISTER_TIME) VALUES ( ?, ?, ?, ?, ?, ? )";
	private static final String queryFCA = "SELECT * FROM TB_FC_Account " + "WHERE USERNAME = ?";
	private static final String queryLCinfo = "SELECT LEETUSER, LEETPASS FROM TB_FC_Account " + "WHERE USERNAME = ?";
	private static final String insertRecordDetail = "INSERT INTO TB_RECORD_DETAIL (USER_ID, GOAL, START_TIME) "
			+ "VALUES ( (select _ID from tb_fc_account where username = ? ), ?, ? )";
	private static final String insertLocationRecord = "INSERT INTO TB_RECORD_STAT "
			+ "(USER_ID, SOLVED_PROB, LOCATION) VALUES ( (select _ID from tb_fc_account where username = ? ), ?, ? )";
	private static final String queryStats = "select count(*) c, location FROM focuscodedb.tb_record_stat "
			+ "where user_id = (select _ID from tb_fc_account where username = ? )"
			+ " group by LOCATION order by c desc";

	private static final String PROGRESS_URL = "https://leetcode.com/progress/";

	/**
	 * Insert a new user account into database. Used in register servlet.
	 * 
	 * @param userName
	 * @param pwd
	 * @param lcname
	 * @param lcpwd
	 * @param email
	 * @return success
	 */
	public static boolean insertFCAccount(String userName, String pwd, String lcname, String lcpwd, String email) {

		Connection conn = null;

		try {
			// step1: Register jdbc driver
			Class.forName(JDBC_Driver);
			System.out.println("Success loading Mysql Driver!");
		} catch (Exception e) {
			System.out.println("Fail in loading Mysql Driver!");
			e.printStackTrace();
		}

		try {
			// step2: Open a connection
			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName, PassWord);
			System.out.println("Success connecting to database.");
		} catch (Exception e) {
			System.out.println("Fail in connecting to database.");
			e.printStackTrace();
		}

		try {
			// step3: Execute query
			PreparedStatement ps = conn.prepareStatement(insertFCA);
			ps.setString(1, userName);
			ps.setString(2, pwd);
			ps.setString(3, lcname);
			ps.setString(4, lcpwd);
			ps.setString(5, email);

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
			String time = sdf.format(cal.getTime());
			ps.setString(6, time);

			ps.execute();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * Query the DB for authentication
	 * 
	 * @param username
	 * @param pwd
	 * @return true for success
	 */
	public static boolean verifyUserPwd(String username, String pwd) {

		Connection conn = null;

		try {
			// step1: Register jdbc driver
			Class.forName(JDBC_Driver);

			// step2: Open a connection
			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName, PassWord);

			PreparedStatement ps = conn.prepareStatement(queryFCA);
			// get the pwd
			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				if (rs.getString("PASSWORD").equals(pwd))
					return true;
			}

		} catch (Exception e) {
			System.out.println("Fail in loading Mysql Driver!");
			e.printStackTrace();
		}

		return false;
	}

	/**
	 * Get LC acc/pwd with username
	 * 
	 * @param username
	 * @return string
	 */
	public static String queryLCinfo(String username) {

		String res = "";

		Connection conn = null;

		try {
			Class.forName(JDBC_Driver);

			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName, PassWord);

			PreparedStatement ps = conn.prepareStatement(queryLCinfo);

			// query LEETUSER, LEETPASS
			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {

				String lcusr = rs.getString("LEETUSER");
				String lcpwd = rs.getString("LEETPASS");

				res = lcusr + "," + lcpwd;

				ConnLeetCode connection = new ConnLeetCode();

				if (connection.loginLeetcode(lcusr, lcpwd)) {
					connection.fetchPage(PROGRESS_URL);
					int ac_count = connection.getACCount();
					res += "," + ac_count;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return res;
	}

	/**
	 * insert progress records into tb_record_detail & tb_record_stats
	 * 
	 * @param name
	 * @param pro
	 * @param location
	 * @param time
	 */
	public static void insertProgressRecord(String name, String pro, String location, String time) {

		Connection conn = null;

		try {

			Class.forName(JDBC_Driver);

			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName, PassWord);

			PreparedStatement ps = conn.prepareStatement(insertRecordDetail);
			ps.setString(1, name);
			ps.setString(2, pro);
			ps.setString(3, time);

			ps.execute();

			ps = conn.prepareStatement(insertLocationRecord);
			ps.setString(1, name);
			ps.setString(2, pro);
			ps.setString(3, location);

			ps.execute();

		} catch (Exception e) {
			System.out.println("Failed in inserting records!");
			e.printStackTrace();
		}

	}

	/**
	 * Retrieve the user's favorite problem-solving location from database.
	 * 
	 * @param username
	 * @return
	 */
	public static String queryUserStats(String username) {

		String res = "";

		Connection conn = null;

		try {
			Class.forName(JDBC_Driver);

			conn = DriverManager.getConnection(DB_URL + DB_NAME, UserName, PassWord);

			PreparedStatement ps = conn.prepareStatement(queryStats);
			ps.setString(1, username);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {

				res = rs.getString("LOCATION");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return res;

	}
	

}
