package util;

/**
 * @author ximengw
 *
 * FileIO provides IO utilities for Files and/or DB
 */
public class FileIO {
	
	
	
	

}
