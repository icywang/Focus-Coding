package servlet;

/**
 * @author ximengw
 * 
 * Account Server is responsible for accepting login/logout requests
 * , validating account credentials and providing related information
 * back to the clients
 *
 */
public interface LoginServerInterface {

	/**
	 * 
	 * @return check result
	 */
	public boolean verifyLogin(String username, String passwd);
	
	/**
	 * 
	 * @param username
	 * @param passwd
	 * @return register result
	 */
	public boolean registerAcc(String username, String passwd);
	
}
