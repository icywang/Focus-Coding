package cmu.procrastination.focuscoding.ws.local;

/**
 * Created by ximengw on 4/14/2016.
 *
 * Blocks target processes
 */
public interface BlockFB {

    public boolean blockFB();

}
